#!/bin/bash

echo "Iniciando el bot..."
node index.js