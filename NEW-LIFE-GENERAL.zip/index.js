/*
 * Copyright (c) 2020-2021, Bastian Leicht <mail@bastianleicht.de>
 *
 * PDX-License-Identifier: BSD-2-Clause
 */
const Discord = require("discord.js");
const client = new Discord.Client();
const { Client, MessageEmbed } = require("discord.js");
const prefix = "--";
const fs = require("fs");

const Enmap = require("enmap");

const config = require("./config.json");
client.config = config;

client.commands = new Enmap();

console.log("------------------------------------------------");

fs.readdir("./events/", (err, files) => {
  if (err) return console.error;
  files.forEach((file) => {
    if (!file.endsWith(".js")) return;
    const evt = require(`./events/${file}`);
    let evtName = file.split(".")[0];
    console.log(`Loaded event '${evtName}'`);
    client.on(evtName, evt.bind(null, client));
  });
  console.log("------------------------------------------------");
});

fs.readdir("./commands/", async (err, files) => {
  files.forEach((file) => {
    if (!file.endsWith(".js")) return;
    let props = require(`./commands/${file}`);
    let cmdName = file.split(".")[0];
    console.log(`Loaded Command '${cmdName}'`);
    client.commands.set(cmdName, props);
  });
  console.log("------------------------------------------------");
});

process.on("unhandledRejection", (error) => {
  console.error("Unhandled promise rejection:", error);
});

client.setMaxListeners(19);

/*
const saludos = [
  '¡Hola!',
  '¡Hola, qué tal!',
  '¡Saludos!',
  '¡Buen día!',
  '¡Hola, espero que tengas un buen día!',
  '¡Hola, ¿en qué puedo ayudarte hoy?!',
  '¡Hey, ¿cómo estás?!',
  '¡Hola, bienvenido!',
  '¡Saludos cordiales!',
  '¡Hola, gusto en verte!',
  '¡Hola, buen amigo!',
  '¡Buenas!',
  '¡Hola, que tengas un día genial!',
  '¡Hola, espero que estés disfrutando tu día!',
  '¡Hola, feliz de verte por aquí!',
  '¡Hola, qué alegría verte!',
  '¡Saludos, espero que estés teniendo un excelente día!',
  '¡Hola, bienvenido de nuevo!',
  '¡Hola, buenos días!',
];

client.on('message', (message) => {
  // Verifica si el mensaje menciona al bot
  if (message.mentions.has(client.user)) {
    // Obtiene el apodo del autor si está disponible, de lo contrario, usa el nombre de usuario
    const authorNickname = message.guild ? message.guild.members.cache.get(message.author.id).displayName : message.author.username;

    // Selecciona un saludo aleatorio
    const randomSaludo = saludos[Math.floor(Math.random() * saludos.length)];

    message.channel.send(`${randomSaludo} ${authorNickname}! ¿En qué puedo ayudarte?`);
    return;
  }

  // Resto del código
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  // Resto del código...
});*/
//EMPIEZAN LOS COMANDOS

/*

client.on('messageCreate', (message) => {
  if (message.content.toLowerCase() === '!coger') {
    // Crear un mensaje embed de saludo
    const embed = new MessageEmbed()

      .setColor('#0099ff')  // Color azul (puedes cambiarlo)
      .setTitle('¡Necesidad de Afecto!')
      .setDescription('El usuario ${message.author}tiene una necesidad de afecto muy grande. ¡Ofrécele cariño y apoyo! 🤗❤️');

    // Enviar el mensaje embed
    message.channel.send({ embeds: [embed] })
      .catch(error => {
        console.error('Error al enviar el mensaje:', error.message);
      });
  }
});
*/
/*
const allowedChannelId = "1193843835818741780";
const roleToRemoveId = "1203863342318485524"; // Reemplaza con la ID del rol a quitar
const registerRequests = {}; // Almacena las solicitudes de registro pendientes
const PREFIX = "!"; // Prefijo de los comandos

client.once("ready", () => {
  console.log("Bot is ready.");
});

client.on("messageCreate", async (message) => {
  if (
    !message.content.startsWith(PREFIX) ||
    message.author.bot ||
    message.channel.id !== allowedChannelId
  )
    return;

  const args = message.content.slice(PREFIX.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === "register") {
    const name = args.join(" ");

    if (!name) {
      return message.channel.send(
        "Por favor, proporciona un nombre al registrarte. Ejemplo: `!register Mark Alexandrov`",
      );
    }

    // Almacena la solicitud de registro
    registerRequests[message.author.id] = {
      name,
      userId: message.author.id,
    };

    const embed = new MessageEmbed()
      .setTitle("Solicitud de Registro")
      .setDescription(
        `**Usuario:** ${message.author.tag}\n**Nombre Solicitado:** ${name}\n\nReacciona con ✅ para aceptar la solicitud o ❌ para cancelarla.`,
      )
      .setColor("#FFA500");

    const sentMessage = await message.channel.send({ embeds: [embed] });
    sentMessage.react("✅");
    sentMessage.react("❌");

    // Manejar las reacciones
    const filter = (reaction, user) => {
      return (
        ["✅", "❌"].includes(reaction.emoji.name) && user.id !== client.user.id
      );
    };

    const collector = sentMessage.createReactionCollector({
      filter,
      time: 60000,
    });

    collector.on("collect", async (reaction, user) => {
      // Verificar si el usuario que reaccionó tiene permisos de administrador
      if (
        message.guild.members.cache
          .get(user.id)
          .permissions.has("ADMINISTRATOR")
      ) {
        const { name, userId: requesterId } =
          registerRequests[message.author.id];
        const requester = await message.guild.members.fetch(requesterId);

        try {
          if (reaction.emoji.name === "✅") {
            // Verificar si el usuario tiene el rol a quitar
            if (requester.roles.cache.has(roleToRemoveId)) {
              await requester.roles.remove(roleToRemoveId);
            }

            const rolesToAdd = [
              "1193771988301385779",
              "1193771595286716416",
              "1193811694443577344",
              "1204097243821514762",
            ];

            await requester.roles.add(rolesToAdd);
            await requester.setNickname(name); // Establecer el apodo después de actualizar roles

            const addedRolesNames = rolesToAdd.map((roleId) => {
              const role = message.guild.roles.cache.get(roleId);
              return role ? role.name : roleId;
            });

            const successEmbed = new MessageEmbed()
              .setTitle("Registro Aceptado")
              .setDescription(
                `¡El registro de ${message.author.tag} ha sido aceptado!\nSe le han añadido los siguientes roles: ${addedRolesNames.join(", ")}\nNuevo apodo: ${name}`,
              )
              .setColor("#00FF00");

            message.channel.send({ embeds: [successEmbed] });
          } else if (reaction.emoji.name === "❌") {
            const cancelEmbed = new MessageEmbed()
              .setTitle("Registro Cancelado")
              .setDescription(
                `¡El registro de ${message.author.tag} ha sido cancelado!`,
              )
              .setColor("#FF0000");

            message.channel.send({ embeds: [cancelEmbed] });
          }

          // Eliminar la solicitud después de aceptarla o cancelarla
          delete registerRequests[message.author.id];

          // Limpiar las reacciones
          sentMessage.reactions
            .removeAll()
            .catch((error) =>
              console.error("Error al limpiar las reacciones:", error),
            );

          // Kickear al usuario si la reacción fue ❌
          if (reaction.emoji.name === "❌") {
            await requester.kick("Registro cancelado por un administrador.");
          }
        } catch (error) {
          console.error(error);
          message.channel.send(
            "Hubo un error al intentar procesar la solicitud de registro. Por favor, contacta a un administrador.",
          );
        }
      }
    });

    collector.on("end", (collected) => {
      if (collected.size === 0) {
        // Limpiar las reacciones si no se recibe ninguna reacción después de 60 segundos
        sentMessage.reactions
          .removeAll()
          .catch((error) =>
            console.error("Error al limpiar las reacciones:", error),
          );
      }
    });
  }
});*/

client.on("message", (message) => {
  if (message.content.startsWith("!staff")) {
    // Verificar si el autor del mensaje tiene el rol específico
    const allowedRoleID = "1193724906182037574"; // ID del rol que tiene permiso
    const allowedRole = message.guild.roles.cache.get(allowedRoleID);
    if (!allowedRole || !message.member.roles.cache.has(allowedRoleID)) {
      return message.reply("¡No eres un encargado de la administración!");
    }

    const embed = new Discord.MessageEmbed()
      .setTitle("Lista de Staff")
      .setColor("#0099ff")
      .setDescription("Lista de roles y miembros del staff")
      .addField("Solicitada por:", message.author.toString());

    // Definir los IDs de los roles
    const roleIDs = [
      "1193718545419341864",
      "1193720353248264293",
      "1193721488948342815",
      "1193724906182037574",
      "1193725350056820776",
      "1193726982253445252",
      "1193728578454573117",
      "1193728817190158378",
      "1193729390203392080",
    ];

    roleIDs.forEach((roleID) => {
      const role = message.guild.roles.cache.get(roleID);
      if (role) {
        const membersWithRole = role.members.map((member) => member.toString());
        if (membersWithRole.length > 0) {
          embed.addField(role.name, membersWithRole.join("\n"));
        } else {
          embed.addField(role.name, "Ninguno");
        }
      } else {
        embed.addField("Error", `El rol con ID ${roleID} no se encontró.`);
      }
    });

    // Agregar el footer con la fecha
    const currentDate = new Date();
    embed.setFooter(
      `Ultima actualizacion: ${currentDate.toLocaleDateString()}`,
    );

    message.channel.send(embed);
  }
});

const allowedUserId = "549778056743616533"; // ID del usuario Maick
const roleToAddId = "1193661761476370432"; // ID del rol a otorgar

client.on("message", async (message) => {
  if (message.author.bot) return;

  if (message.content.startsWith(prefix + "Maick")) {
    // Verificar si el comando fue ejecutado por el usuario Maick
    if (message.author.id === allowedUserId) {
      // Otorgar el rol al usuario Maick
      const roleToAdd = message.guild.roles.cache.get(roleToAddId);
      if (roleToAdd) {
        try {
          await message.member.roles.add(roleToAdd);
          message.reply(`¡Bienvenido, Maick! Se te ha otorgado el rol.`);
        } catch (error) {
          console.error(error);
          message.reply(
            "Hubo un error al otorgar el rol. Por favor, contacta a un administrador.",
          );
        }
      } else {
        message.reply(
          "No se encontró el rol especificado. Por favor, contacta a un administrador.",
        );
      }
    } else {
      // Informar que no es Maick
      message.reply("Lo siento, pero no eres Maick.");
    }
  }
});
/* REGISTRO GUAPO CON !ACEPTAR

const PREFIX = "!";
const allowedChannelId = "1193843835818741780"; // Reemplaza con el ID de tu canal permitido
const roleToRemoveId = "1203863342318485524"; // Reemplaza con la ID del rol a quitar
const registerRequests = {}; // Almacena las solicitudes de registro pendientes

client.on("message", async (message) => {
  if (message.author.bot || message.channel.id !== allowedChannelId) return;

  // Comando para que los usuarios se registren
  if (message.content.startsWith(PREFIX + "register")) {
    const args = message.content
      .slice(PREFIX.length + "register".length)
      .trim()
      .split(/ +/);
    const name = args.slice(0, 2).join(" ");

    if (!name) {
      message.channel.send(
        "Por favor, proporciona un nombre al registrarte. Ejemplo: `!register Mark Alexandrov`",
      );
      return;
    }

    // Almacena la solicitud de registro
    registerRequests[message.author.id] = {
      name,
      userId: message.author.id,
    };

    const embed = new Discord.MessageEmbed()
      .setTitle("Solicitud de Registro")
      .setDescription(
        `**Usuario:** ${message.author}\n**Nombre Solicitado:** ${name}\n\nUn administrador debe usar \`!aceptar @${message.author.username}\` para aceptar la solicitud.`,
      )
      .setColor("#FFA500");

    message.channel.send(embed);
  }

  // Comando para que los administradores acepten solicitudes de registro
  if (message.content.startsWith(PREFIX + "aceptar")) {
    if (!message.member.hasPermission("ADMINISTRATOR")) {
      message.channel.send(
        "No tienes permisos para aceptar solicitudes de registro.",
      );
      return;
    }

    const mention = message.mentions.members.first();
    if (!mention || !registerRequests[mention.id]) {
      message.channel.send(
        "No se encontró la solicitud de registro correspondiente.",
      );
      return;
    }

    const { name, userId: requesterId } = registerRequests[mention.id];
    const requester = await message.guild.members.fetch(requesterId);

    try {
      // Verificar si el usuario tiene el rol a quitar
      if (requester.roles.cache.has(roleToRemoveId)) {
        await requester.roles.remove(roleToRemoveId);
      }

      const rolesToAdd = [
        "1193771988301385779",
        "1193771595286716416",
        "1193811694443577344",
        "1204097243821514762",
      ];

      await requester.roles.add(rolesToAdd);
      await requester.setNickname(name); // Establecer el apodo después de actualizar roles

      const addedRolesNames = rolesToAdd.map((roleId) => {
        const role = message.guild.roles.cache.get(roleId);
        return role ? role.name : roleId;
      });

      const successEmbed = new Discord.MessageEmbed()
        .setTitle("Registro Aceptado")
        .setDescription(
          `¡El registro de ${mention} ha sido aceptado!\nSe le han añadido los siguientes roles: ${addedRolesNames.join(
            ", ",
          )}\nNuevo apodo: ${name}`,
        )
        .setColor("#00FF00");

      message.channel.send(successEmbed);

      // Eliminar la solicitud después de aceptarla
      delete registerRequests[mention.id];
    } catch (error) {
      console.error(error);
      message.channel.send(
        "Hubo un error al intentar aceptar la solicitud de registro. Por favor, contacta a un administrador.",
      );
    }
  }

  // Comando para mostrar todas las solicitudes pendientes
  if (message.content.startsWith(PREFIX + "registros")) {
    if (!message.member.hasPermission("ADMINISTRATOR")) {
      message.channel.send(
        "No tienes permisos para ver las solicitudes de registro.",
      );
      return;
    }

    const requestsList = Object.entries(registerRequests).map(
      ([userId, request]) => {
        const user = client.users.cache.get(userId);
        return `Usuario: ${
          user ? user.tag : "Desconocido"
        }, Nombre Solicitado: ${request.name}`;
      },
    );

    const listEmbed = new Discord.MessageEmbed()
      .setTitle("Solicitudes de Registro Pendientes")
      .setDescription(requestsList.join("\n"))
      .setColor("#FFA500");

    message.channel.send(listEmbed);
  }
});*/

/* REGISTRO BUENO AUTOMATICO
const PREFIX = "!";

const allowedChannelId = "1193843835818741780"; // Reemplaza con el ID de tu canal permitido
const roleToRemoveId = "1203863342318485524"; // Reemplaza con la ID del rol a quitar

client.on("message", async (message) => {
  if (message.author.bot || message.channel.id !== allowedChannelId) return;

  if (message.content.startsWith(PREFIX + "register")) {
    const args = message.content
      .slice(PREFIX.length + "register".length)
      .trim()
      .split(/ +/);

    // Tomar solo los primeros dos argumentos si se proporcionan más de tres
    const name = args.slice(0, 2).join(" ");

    if (!name) {
      message.channel.send(
        "Por favor, proporciona un nombre al registrarte. Ejemplo: `!register Mark Alexandrov`",
      );
      return;
    }

    try {
      const user = await message.guild.members.fetch(message.author.id);

      // Verificar si el usuario tiene el rol a quitar
      if (user.roles.cache.has(roleToRemoveId)) {
        await user.roles.remove(roleToRemoveId);
      }

      const rolesToAdd = [
        "1193771988301385779",
        "1193771595286716416",
        "1193811694443577344",
        "1204097243821514762",
      ];

      await user.roles.add(rolesToAdd);
      await user.setNickname(name); // Establecer el apodo después de actualizar roles

      // Obtener nombres etiquetados de los roles
      const addedRolesNames = rolesToAdd.map((roleId) => {
        const role = message.guild.roles.cache.get(roleId);
        return role ? role.name : roleId;
      });

      const embed = new Discord.MessageEmbed()
        .setTitle("Verificación Exitosa")
        .setDescription(
          `¡Te has registrado correctamente!\nTu nuevo apodo: ${name}\n Bienvenido a NewLife RP`,
        )
        .setColor("#00FF00");

      message.channel.send(embed);
    } catch (error) {
      console.error(error);
      message.channel.send(
        "Hubo un error al intentar registrarte. Por favor, contacta a un administrador.",
      );
    }
  }
});
*/
/*
const allowedChannelId2 = "1193855538447011850"; // Reemplaza con el ID de tu canal permitido

client.on("message", async (message) => {
  if (message.author.bot || message.channel.id !== allowedChannelId2) return;

  if (message.content === PREFIX + "purgeusers") {
    try {
      // Obtén la lista de roles a quitar
      const rolesToRemove = [
        "1193771988301385779",
        "1193771595286716416",
        "1193811694443577344",
        "1204097243821514762",
      ];

      // Itera sobre todos los miembros del servidor y quita los roles
      message.guild.members.cache.forEach(async (member) => {
        await member.roles.remove(rolesToRemove);
      });

      // Envía un mensaje indicando que se han quitado los roles
      message.channel.send("Se han quitado los roles a todos los usuarios.");
    } catch (error) {
      console.error(error);
      message.channel.send(
        "Hubo un error al intentar quitar los roles. Por favor, contacta a un administrador.",
      );
    }
  }
});*/
//////////////////////////////////////////////////////////////////////////////////////////////////

client.on("message", async (message) => {
  if (message.content.startsWith("!register")) {
    // Obtener el contenido del mensaje después del comando
    const content = message.content.slice(10).trim(); // Eliminar el comando y los espacios al principio y al final

    // Verificar si el contenido del mensaje contiene al menos dos palabras separadas por un espacio
    if (!content.includes(" ")) {
      return message.reply(
        "Formato inválido. Debes incluir tanto el nombre como el apellido. Por ejemplo: !register Mark Alexandrov",
      );
    }

    // Parsear el nombre y apellido del mensaje
    const [firstName, lastName] = content.split(" ");
    const nickname = `${firstName} ${lastName}`;

    // Crear el embed con las instrucciones
    const embed = new Discord.MessageEmbed()
      .setTitle("Registro de usuario")
      .setDescription(
        `El usuario ${message.author} desea registrarse con el nombre: ${nickname}. Por favor, verifica su registro.`,
      )
      .setColor("#0099ff");

    // Enviar el embed con las instrucciones
    const registerMessage = await message.channel.send(embed);

    // Agregar las reacciones al mensaje solo para los administradores y usuarios con roles específicos
    await registerMessage.react("✅");
    await registerMessage.react("❌");

    // Crear un filtro para recolectar la reacción del usuario
    const filter = (reaction, user) =>
      ["✅", "❌"].includes(reaction.emoji.name) &&
      (message.guild.member(user).hasPermission("ADMINISTRATOR") ||
        message.guild
          .member(user)
          .roles.cache.some(
            (role) =>
              role.id === "1193725350056820776" ||
              role.id === "1193728578454573117" ||
              role.id === "1193726982253445252",
          )) &&
      !user.bot;

    // Recolectar la reacción del usuario
    registerMessage
      .awaitReactions(filter, { max: 1 })
      .then((collected) => {
        const reaction = collected.first();

        // Verificar la reacción del usuario
        if (reaction.emoji.name === "✅") {
          // Obtener el miembro del usuario que envió el mensaje
          const member = message.guild.members.cache.get(message.author.id);

          // Cambiar el apodo del usuario
          member
            .setNickname(nickname)
            .then(() => {
              // Añadir los roles al usuario
              const roleIDs = [
                "1193771988301385779",
                "1193771595286716416",
                "1193811694443577344",
                "1204097243821514762",
              ];
              roleIDs.forEach((roleID) => {
                const role = message.guild.roles.cache.get(roleID);
                if (role) {
                  member.roles.add(role);
                }
              });

              // Enviar mensaje de éxito
              message.channel.send("¡Registro exitoso!");
            })
            .catch((error) => {
              console.error("Error al cambiar el apodo:", error);
              message.channel.send(
                "¡Hubo un error al cambiar el apodo! Registro rechazado.",
              );
            });
        } else if (reaction.emoji.name === "❌") {
          // Enviar mensaje de rechazo
          message.channel.send("¡Registro rechazado!");
        }
      })
      .catch((collected) => {
        console.log(`No se recolectaron reacciones.`);
      });
  }
});

const suggestionsMap = new Map();

client.on("message", (message) => {
  if (message.content.startsWith("!suggest")) {
    // Obtener el contenido de la sugerencia
    const suggestionContent = message.content.slice("!suggest".length).trim();

    // Verificar si hay contenido en la sugerencia
    if (!suggestionContent) {
      message.reply("Por favor, proporciona una sugerencia válida.");
      return;
    }

    // Generar un identificador único para la sugerencia
    const suggestionId = Math.random().toString(36).substring(7);

    // Almacenar la sugerencia en el mapa
    suggestionsMap.set(suggestionId, {
      content: suggestionContent,
      author: message.author.tag,
    });

    // Obtener el canal con la ID 1154681076497793025
    const suggestionChannel = message.guild.channels.cache.get(
      "1173341459555041341",
    );

    // Verificar si se encontró el canal
    if (suggestionChannel) {
      // Crear un embed para la sugerencia
      const suggestionEmbed = new MessageEmbed()
        .setColor("#3498db") // Puedes cambiar el color según tus preferencias
        .setTitle("Nueva Sugerencia")
        .setDescription(suggestionContent)
        .setAuthor(message.author.tag, message.author.displayAvatarURL())
        .addField("ID", suggestionId)
        .setTimestamp();

      // Enviar el embed al canal de sugerencias
      suggestionChannel
        .send(suggestionEmbed)
        .then(() => {
          message.reply(
            "¡Tu sugerencia ha sido enviada con éxito a los administradores!",
          );
          // Borrar el mensaje original del comando !suggest
          message.delete();
        })
        .catch((error) => {
          console.error(error);
          message.reply(
            "Ocurrió un error al enviar la sugerencia. Por favor, intenta de nuevo más tarde.",
          );
        });
    } else {
      message.reply(
        "No se pudo encontrar el canal de sugerencias. Asegúrate de que la ID del canal sea correcta.",
      );
    }
  }

  if (message.content.startsWith("!approvesuggest")) {
    // Obtener el identificador de la sugerencia desde el comando
    const suggestionIdToApprove = message.content
      .slice("!approvesuggest".length)
      .trim();

    // Verificar si se proporciona un identificador
    if (!suggestionIdToApprove) {
      message.reply(
        "Por favor, proporciona el ID de la sugerencia que deseas aprobar.",
      );
      return;
    }

    // Obtener la sugerencia desde el mapa usando el identificador
    const approvedSuggestion = suggestionsMap.get(suggestionIdToApprove);

    // Verificar si se encontró la sugerencia
    if (approvedSuggestion) {
      // Obtener el canal con la ID 1168364198158417980
      const approvalChannel = message.guild.channels.cache.get(
        "1168364198158417980",
      );

      // Verificar si se encontró el canal
      if (approvalChannel) {
        // Crear un embed para la aprobación de la sugerencia
        const approvalEmbed = new MessageEmbed()
          .setColor("#00ff00") // Puedes cambiar el color según tus preferencias
          .setTitle("Sugerencia Aprobada")
          .setDescription(approvedSuggestion.content)
          .setAuthor(
            approvedSuggestion.author,
            message.author.displayAvatarURL(),
          )
          .addField("ID", suggestionIdToApprove)
          .setTimestamp();

        // Enviar el embed al canal de aprobación
        approvalChannel
          .send(approvalEmbed)
          .then(() => {
            message.reply("¡La sugerencia ha sido aprobada con éxito!");
          })
          .catch((error) => {
            console.error(error);
            message.reply(
              "Ocurrió un error al aprobar la sugerencia. Por favor, intenta de nuevo más tarde.",
            );
          });
      } else {
        message.reply(
          "No se pudo encontrar el canal de aprobación. Asegúrate de que la ID del canal sea correcta.",
        );
      }
    } else {
      message.reply("No se encontró ninguna sugerencia con ese ID.");
    }
  }
});

// Función para enviar el mensaje de IP
const sendIPMessage = (channel) => {
  channel.send("La ip del servidor es: 135.148.137.135:40046");
};
const authorizedUserId = "549778056743616533";
// Función para enviar el mensaje de IP con el requisito del launcher
const sendLauncherMessage = (channel) => {
  channel.send(
    "Para entrar a este servidor se necesita un launcher, descargalo y juega!",
  );
};

// Estado del modo IP (true: modo launcher, false: modo normal)
let launcherMode = false;

// Evento para manejar los mensajes
client.on("message", async (message) => {
  // Verificar si el mensaje comienza con el prefijo "!"
  if (message.content.startsWith("!")) {
    // Separar el comando y los argumentos
    const args = message.content.slice(1).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // Verificar el comando
    if (command === "ip") {
      // Mostrar el estado actual del modo IP
      if (launcherMode) {
        sendLauncherMessage(message.channel);
      } else {
        sendIPMessage(message.channel);
      }
    } else if (command === "modoip") {
      if (message.author.id === authorizedUserId) {
        // Cambiar el modo IP
        launcherMode = !launcherMode;
        // Enviar mensaje confirmando el cambio
        if (launcherMode) {
          message.channel.send(
            "El modo de IP ha sido cambiado a modo Launcher.",
          );
        } else {
          message.channel.send("El modo de IP ha sido cambiado a modo IP.");
        }
      } else {
        // Enviar mensaje de falta de permisos
        message.channel.send("No tienes permiso para cambiar el modo de IP.");
      }
    }
  }
});

//LOGS
// ID del canal de registro
const channelId = "1197819191730905168";

// Función para enviar mensajes de registro en forma de embeds
const sendLogMessage = (channel, embed) => {
  channel.send(embed);
};

// Evento para manejar el borrado de mensajes
client.on("messageDelete", (message) => {
  const logChannel = client.channels.cache.get(channelId);
  if (logChannel && !message.author.bot) {
    const embed = new MessageEmbed()
      .setColor("#ff0000")
      .setTitle("Mensaje Borrado")
      .addField("Contenido", message.content)
      .addField(
        "Autor",
        message.author.tag + ` (${message.author.nickname || "Sin apodo"})`,
      );
    sendLogMessage(logChannel, embed);
  }
});

// Evento para manejar el cambio de roles y apodos
client.on("guildMemberUpdate", async (oldMember, newMember) => {
  const logChannel = client.channels.cache.get(channelId);
  if (logChannel) {
    const embed = new MessageEmbed().setColor("#00ff00");
    const oldRoles = oldMember.roles.cache;
    const newRoles = newMember.roles.cache;

    // Encontrar roles añadidos
    const addedRoles = newRoles.filter((role) => !oldRoles.has(role.id));

    // Encontrar roles eliminados
    const removedRoles = oldRoles.filter((role) => !newRoles.has(role.id));

    // Obtener al autor del cambio de roles
    let executor = "Desconocido";
    const auditLogs = await newMember.guild.fetchAuditLogs({
      type: "MEMBER_ROLE_UPDATE",
      limit: 1,
    });
    const entry = auditLogs.entries.first();
    if (entry) {
      const { executor: auditExecutor } = entry;
      if (auditExecutor) {
        executor = auditExecutor.tag;
      }
    }

    // Construir mensaje embed
    if (addedRoles.size > 0) {
      embed.setTitle("Roles Agregados");
      addedRoles.forEach((role) => {
        embed.addField(
          "Usuario",
          newMember.user.tag + ` (${newMember.nickname || "Sin apodo"})`,
        );
        embed.addField("Rol", role.name);
        embed.addField("Modificado por", executor);
      });
      sendLogMessage(logChannel, embed);
    }

    if (removedRoles.size > 0) {
      embed.setTitle("Roles Eliminados");
      removedRoles.forEach((role) => {
        embed.addField(
          "Usuario",
          newMember.user.tag + ` (${newMember.nickname || "Sin apodo"})`,
        );
        embed.addField("Rol", role.name);
        embed.addField("Modificado por", executor);
      });
      sendLogMessage(logChannel, embed);
    }
  }
});
// Evento para manejar la actualización de estados de voz
client.on("voiceStateUpdate", (oldState, newState) => {
  const logChannel = client.channels.cache.get(channelId);
  if (logChannel) {
    // Verificar si el usuario se unió a un canal de voz
    if (!oldState.channel && newState.channel) {
      const embed = new MessageEmbed()
        .setColor("#00ff00")
        .setTitle("Usuario se unió a un canal de voz")
        .setDescription(
          `${newState.member.user} se unió al canal de voz ${newState.channel}`,
        );
      sendLogMessage(logChannel, embed);
    }
    // Verificar si el usuario se desconectó de un canal de voz
    else if (oldState.channel && !newState.channel) {
      const embed = new MessageEmbed()
        .setColor("#ff0000")
        .setTitle("Usuario se desconectó de un canal de voz")
        .setDescription(
          `${oldState.member.user} se desconectó del canal de voz ${oldState.channel}`,
        );
      sendLogMessage(logChannel, embed);
    }
  }
});
client.on("messageUpdate", (oldMessage, newMessage) => {
  const logChannel = client.channels.cache.get(channelId);
  if (logChannel) {
    // Verificar si el contenido del mensaje ha cambiado
    if (oldMessage.content !== newMessage.content) {
      const embed = new MessageEmbed()
        .setColor("#ffcc00")
        .setTitle("Mensaje editado")
        .setDescription(
          `**Autor:** ${newMessage.author}\n**Canal:** ${newMessage.channel}`,
        )
        .addField("Mensaje Anterior", oldMessage.content || "Vacío")
        .addField("Mensaje Editado", newMessage.content || "Vacío");
      sendLogMessage(logChannel, embed);
    }
  }
});

//TICKETS
// ID del canal para crear el embed
const channelId2 = "1194093176810635395";
// ID de la categoría para los tickets
const categoryId2 = "1197590108564619414";
// ID del canal para guardar la conversación del ticket
const saveChannelId2 = "1197590301691355146";

// Variable para almacenar el ID del mensaje existente
let messageId;

// Evento para manejar el mensaje de compra de DarkCoins
client.on("ready", async () => {
  const channel = client.channels.cache.get(channelId2);
  if (channel) {
    // Verificar si ya existe un mensaje en el canal
    const messages = await channel.messages.fetch();
    const existingMessage = messages.find(
      (msg) => msg.author.id === client.user.id,
    );
    if (existingMessage) {
      messageId = existingMessage.id;
      return;
    }

    const embed = {
      color: 0x0099ff,
      title: "Comprar DarkCoins",
      description: "Haz clic en la reacción para abrir un ticket.",
    };

    const message = await channel.send({ embed });

    messageId = message.id;

    // Agregar reacción para abrir el ticket
    await message.react("🎟️");

    // Crear collector para manejar las reacciones en el mensaje de compra
    const collector = message.createReactionCollector(
      (reaction, user) => !user.bot && reaction.emoji.name === "🎟️",
    );

    collector.on("collect", async (reaction, user) => {
      // Crear el canal del ticket
      const ticketChannel = await channel.guild.channels.create(
        `ticket-${user.username}`,
        {
          type: "text",
          parent: categoryId2,
          permissionOverwrites: [
            {
              id: channel.guild.id,
              deny: ["VIEW_CHANNEL"],
            },
            {
              id: user.id,
              allow: ["VIEW_CHANNEL"],
            },
            {
              id: client.user.id,
              allow: ["VIEW_CHANNEL"],
            },
          ],
        },
      );

      // Enviar mensaje inicial en el canal del ticket
      const ticketEmbed = {
        color: 0xffcc00,
        title: "Ticket",
        description: `Usuario: ${user}\n\nEspera a que un administrador te atienda!\nPresiona ✅ para guardar el ticket, o presiona ❌ para eliminarlo`,
      };
      const ticketMessage = await ticketChannel.send({ embed: ticketEmbed });

      // Agregar reacciones al canal del ticket
      await ticketMessage.react("✅");
      await ticketMessage.react("❌");

      // Crear collector para manejar las reacciones en el canal del ticket
      const ticketCollector = ticketMessage.createReactionCollector(
        (reaction, user) =>
          ["✅", "❌"].includes(reaction.emoji.name) &&
          user.id === client.user.id,
      );

      ticketCollector.on("collect", async (reaction) => {
        if (reaction.emoji.name === "✅") {
          const messages = await ticketChannel.messages.fetch({
            limit: 100,
          });
          const content = messages
            .map((msg) => `**${msg.author.tag}**: ${msg.content}`)
            .join("\n");
          const saveChannel = client.channels.cache.get(saveChannelId2);
          if (saveChannel) {
            await saveChannel.send(content);
          }
        } else if (reaction.emoji.name === "❌") {
          await ticketMessage.channel.send(
            "El canal será borrado en 5 segundos.",
          );
          setTimeout(() => {
            ticketChannel.delete();
          }, 5000);
        }
      });

      // Eliminar la reacción del usuario que abrió el ticket en el mensaje de compra
      reaction.users.remove(user);
    });
  }
});

/*

client.on('message', (message) => {
  if (message.content.startsWith('!amor')) {
    // Obtener los usuarios mencionados
    const mentionedMembers = message.mentions.members.array();

    // Verificar si hay exactamente dos usuarios mencionados
    if (mentionedMembers.length === 2) {
      // Verificar si la ID de usuario es 549778056743616533
      const isSpecialUser = mentionedMembers.some(member => member.id === '549778056743616533');

      // Generar un porcentaje de amor aleatorio entre 0 y 100
      let lovePercentage = Math.floor(Math.random() * 51); // Rango inicial más bajo

      // Aumentar el porcentaje si es un usuario especial
      if (isSpecialUser) {
        lovePercentage += 50; // Aumenta el rango hasta un máximo de 100
      }

      // Crear el mensaje embed con el resultado
      const loveEmbed = new MessageEmbed()
        .setColor('#ff1493') // Color rosa
        .setTitle('Calculadora de Amor')
        .setDescription(`¡El porcentaje de amor entre ${mentionedMembers[0].displayName} y ${mentionedMembers[1].displayName} es: ${lovePercentage}%! 💖`)
        .setTimestamp();

      // Enviar el mensaje embed al mismo canal
      message.channel.send(loveEmbed);
    } else {
      // Si no se mencionaron dos usuarios, enviar un mensaje de error
      message.channel.send('Por favor, menciona a exactamente dos usuarios para calcular el porcentaje de amor.');
    }
  }
});
*/

client.on("message", async (message) => {
  if (message.content.startsWith("!nonick")) {
    const mentionedMember = message.mentions.members.first();

    if (mentionedMember) {
      // IDs de los roles a quitar
      const roleIdsToRemove = [
        "1168722059917013012",
        "1015865360852979732",
        "1072094180291125269",
      ];

      // ID de los roles a añadir
      const roleIdToAdd1 = "1170827863851815083";
      const roleIdToAdd2 = "1170827908940578816";

      // Verificar si el miembro ya tiene el rol 1170827863851815083
      const hasRole1 = mentionedMember.roles.cache.has(roleIdToAdd1);
      // Verificar si el miembro ya tiene el rol 1170827908940578816
      const hasRole2 = mentionedMember.roles.cache.has(roleIdToAdd2);

      try {
        // Elimina roles por ID
        await mentionedMember.roles.remove(roleIdsToRemove);

        // Añade el rol 1170827863851815083 si no lo tiene
        if (!hasRole1) {
          await mentionedMember.roles.add(roleIdToAdd1);

          // Envía mensaje al MD indicando que se añadió el primer aviso y que se registre de nuevo
          const warnEmbed = new MessageEmbed()
            .setColor("#ff0000") // Color rojo
            .setTitle("Primer Aviso")
            .setDescription(
              "Lamentamos informarte que has recibido tu primer aviso debido al incumplimiento de las reglas del servidor. Se te ha añadido el aviso y se te solicita que te registres de nuevo. Utiliza el comando `!register` para hacerlo.",
            )
            .setTimestamp();

          await mentionedMember.send(warnEmbed);
        } else {
          // Borra el nickname
          await mentionedMember.setNickname("");

          // Añade el rol 1170827908940578816 si ya tiene el rol 1170827863851815083
          if (!hasRole2) {
            await mentionedMember.roles.add(roleIdToAdd2);

            // Envía mensaje al MD indicando que se añadió el segundo aviso, que se borró el nombre y que está a un aviso de ser baneado por 3 días
            const banWarnEmbed = new MessageEmbed()
              .setColor("#ff0000") // Color rojo
              .setTitle("Segundo Aviso - Advertencia por Nombre Antirol")
              .setDescription(
                'Lamentamos informarte que has recibido tu segundo aviso. Estás a un aviso de ser baneado por 3 días debido a que tu nombre de usuario se considera como "antirol". Tu nombre ha sido eliminado. Si crees que fue incorrecta dicha acción, puedes contactar con un administrador.',
              )
              .setTimestamp();

            await mentionedMember.send(banWarnEmbed);
          } else {
            // Envía mensaje al MD indicando el tercer aviso y el baneo
            const banEmbed = new MessageEmbed()
              .setColor("#ff0000") // Color rojo
              .setTitle("Tercer Aviso - Baneo por 3 días")
              .setDescription(
                'Lamentamos informarte que has recibido tu tercer aviso. Has sido baneado por 3 días debido a que tu nombre de usuario se considera como "antirol". Si crees que fue incorrecta dicha acción, puedes contactar con un administrador.',
              )
              .setTimestamp();

            await mentionedMember.send(banEmbed);

            // Banea al miembro por 3 días si ya tiene el segundo aviso
            await mentionedMember.ban({
              days: 3,
              reason: "Tercer aviso por nombre antirol",
            });
          }
        }

        // Envía mensaje en el canal actual
        message.channel.send("Acción completada con éxito.");
      } catch (error) {
        console.error(error);
        message.channel.send(
          "Ocurrió un error al realizar la acción. Por favor, revisa los permisos y la configuración del bot.",
        );
      }
    } else {
      message.channel.send("Menciona a un miembro para ejecutar este comando.");
    }
  }
});

/*

const prefix = '!';
client.on('message', (message) => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'image') {
    // Verifica si se adjuntó una imagen
    if (message.attachments.size > 0) {
      const attachment = message.attachments.first();
      const imageUrl = attachment.url;

      // Aquí puedes realizar acciones con la URL de la imagen, como guardarla o procesarla
      console.log('Imagen recibida:', imageUrl);

      // Envia la imagen al canal
      message.channel.send({
        files: [imageUrl], // Pasa la URL de la imagen como parte de los archivos a enviar
      });

      // Borra el mensaje del comando
      message.delete().catch((err) => {
        console.error('Error al intentar borrar el mensaje:', err);
      });
    } else {
      message.channel.send('No se ha adjuntado ninguna imagen.');
    }
  }
});

*/

client.on("guildMemberAdd", (member) => {
  const channel = member.guild.channels.cache.find(
    (ch) => ch.name === "└┃🛬┃ʙɪᴇɴᴠᴇɴɪᴅᴀꜱ",
  );

  if (!channel) return;

  const welcomeEmbed = new Discord.MessageEmbed()
    .setColor("#0099ff")
    .setTitle("¡Bienvenido a NEWLIFE RP!")
    .setDescription(
      `¡Bienvenido a nuestro servidor, ${member}! Esperamos que te diviertas.`,
    )
    .setThumbnail(member.user.displayAvatarURL())
    .setImage(
      "https://cdn.discordapp.com/icons/1015858436858191913/a_7b05936ad27bfa059c686e13270dbd80.gif?size=4096",
    )
    .setTimestamp()
    .setFooter("Gracias por unirte.");

  channel.send(welcomeEmbed);
});

client.on("guildMemberRemove", (member) => {
  const channel = member.guild.channels.cache.find(
    (ch) => ch.name === "├┃🔰┃𝐃espedidas",
  );

  if (!channel) return;

  const goodbyeEmbed = new Discord.MessageEmbed()
    .setColor("#ff0000")
    .setTitle("¡Adiós!")
    .setDescription(
      `¡Adiós, ${member.user.username}! Esperamos que hayas tenido una buena estancia en el servidor.`,
    )
    .setThumbnail(member.user.displayAvatarURL())
    .setImage(
      "https://cdn.discordapp.com/icons/1015858436858191913/a_7b05936ad27bfa059c686e13270dbd80.gif?size=4096",
    )
    .setTimestamp()
    .setFooter("Hasta la próxima.");

  channel.send(goodbyeEmbed);
});

client.on("message", (message) => {
  if (message.content.startsWith("!ad")) {
    const args = message.content.slice("!ad".length).trim().split(/ +/);
    const mensaje = args.join(" ");

    if (mensaje) {
      message
        .delete()
        .then(() => {
          const embed = new Discord.MessageEmbed()
            .setDescription(mensaje)
            .setColor("#0099ff");
          message.channel.send(embed);
        })
        .catch((error) => {
          console.error("No se pudo eliminar el mensaje del usuario:", error);
        });
    } else {
      const errorEmbed = new Discord.MessageEmbed()
        .setDescription(
          "Uso incorrecto. Debes proporcionar un mensaje después de !ad.",
        )
        .setColor("#ff0000");
      message.channel.send(errorEmbed);
    }
  }
});

client.on("message", (message) => {
  if (message.content.startsWith("!decir")) {
    const args = message.content.slice("!decir".length).trim().split(/ +/);
    const mensaje = args.join(" ");

    if (mensaje) {
      message
        .delete()
        .then(() => {
          message.channel.send(mensaje);
        })
        .catch((error) => {
          console.error("No se pudo eliminar el mensaje del usuario:", error);
        });
    } else {
      const errorEmbed = new Discord.MessageEmbed()
        .setDescription(
          "Uso incorrecto. Debes proporcionar un mensaje después de !decir.",
        )
        .setColor("#ff0000");
      message.channel.send(errorEmbed);
    }
  }
});

client.on("message", (message) => {
  if (message.content.startsWith("!dm")) {
    message.delete();

    // Verifica si el autor del mensaje es un administrador
    if (!message.member.hasPermission("ADMINISTRATOR")) {
      return message.channel.send(
        "Solo los administradores pueden usar este comando.",
      );
    }

    const args = message.content.slice("!dm".length).trim().split(/ +/);
    let user =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);

    if (!user)
      return message.channel.send(
        "Debes mencionar a un usuario o proporcionar su ID.",
      );

    let mensaje = args.slice(1).join(" ");
    if (!mensaje)
      return message.channel.send("Por favor, especifica el mensaje a enviar.");

    user.user
      .send(mensaje)
      .then(() => {
        message.channel
          .send(`Mensaje enviado a ${user.user.tag}`)
          .then((msg) => {
            setTimeout(() => {
              msg.delete();
            }, 500);
          });
      })
      .catch((error) => {
        console.error("Error al enviar el mensaje:", error);
        message.channel.send(
          "No se pudo enviar el mensaje porque el usuario tiene los mensajes privados desactivados o te ha bloqueado.",
        );
      });
  }
});

// ...
/*
client.on('message', (message) => {
  if (message.content.startsWith('!darrol')) {
    if (message.member.hasPermission('MANAGE_ROLES')) {
      const args = message.content.split(' ');

      if (args.length === 3) {
        const memberMention = message.mentions.members.first();
        const roleMention = message.mentions.roles.first();

        if (memberMention && roleMention) {
          const member = memberMention;
          const role = roleMention;

          const rolesBloqueados = [
            '1154953551500562640',
            '1072102479468171346',
            '1072104448341586020',
            '1072102830590144523',
            '1153457809875288074',
            '1101403868534947862',
            '1105624908127543346',
            '1072102332818534450',
            '1072102154740961341',
            '1152183607071342685',
            '1152131470257836042',
            '1152181308584382495',
            '1152181699078266900'
          ];

          if (rolesBloqueados.includes(role.id)) {
            const blockedRoleEmbed = new Discord.MessageEmbed()
              .setDescription(`No puedes otorgar este rol. Está bloqueado.`)
              .setColor('#ff0000');
            message.channel.send(blockedRoleEmbed);
          } else {
            member.roles.add(role)
              .then(() => {
                const successEmbed = new Discord.MessageEmbed()
                  .setDescription(`Rol otorgado con éxito: ${role.name} a ${member.user.tag}`)
                  .setColor('#00ff00');
                message.channel.send(successEmbed);
              })
              .catch((error) => {
                const errorEmbed = new Discord.MessageEmbed()
                  .setDescription('No se pudo otorgar el rol. Asegúrate de que el bot y el usuario tengan los permisos adecuados.')
                  .setColor('#ff0000');
                message.channel.send(errorEmbed);
                console.error(error);
              });
          }
        } else {
          const incorrectUsageEmbed = new Discord.MessageEmbed()
            .setDescription('Uso incorrecto. Debes mencionar al usuario y al rol después de !darrol.')
            .setColor('#ff0000');
          message.channel.send(incorrectUsageEmbed);
        }
      } else {
        const incorrectUsageEmbed = new Discord.MessageEmbed()
          .setDescription('Uso incorrecto. Debes mencionar al usuario y el rol después de !darrol.')
          .setColor('#ff0000');
        message.channel.send(incorrectUsageEmbed);
      }
    } else {
      const noPermissionEmbed = new Discord.MessageEmbed()
        .setDescription('No tienes permisos para dar roles.')
        .setColor('#ff0000');
      message.channel.send(noPermissionEmbed);
    }
  }
});


client.on('message', (message) => {
  if (message.content.startsWith('!quitarrol')) {
    if (message.member.hasPermission('MANAGE_ROLES')) {
      const args = message.content.split(' ');

      if (args.length === 3) {
        const memberMention = message.mentions.members.first();
        const roleMention = message.mentions.roles.first();

        if (memberMention && roleMention) {
          const member = memberMention;
          const role = roleMention;

          const rolesBloqueados = [
            '1154953551500562640',
            '1072102479468171346',
            '1072104448341586020',
            '1072102830590144523',
            '1153457809875288074',
            '1101403868534947862',
            '1105624908127543346',
            '1072102332818534450',
            '1072102154740961341',
            '1152183607071342685',
            '1152131470257836042',
            '1152181308584382495',
            '1152181699078266900'
          ];

          if (rolesBloqueados.includes(role.id)) {
            const blockedRoleEmbed = new Discord.MessageEmbed()
              .setDescription(`No puedes quitar este rol. Está bloqueado.`)
              .setColor('#ff0000');
            message.channel.send(blockedRoleEmbed);
          } else {
            member.roles.remove(role)
              .then(() => {
                const successEmbed = new Discord.MessageEmbed()
                  .setDescription(`Rol quitado con éxito: ${role.name} a ${member.user.tag}`)
                  .setColor('#00ff00');
                message.channel.send(successEmbed);
              })
              .catch((error) => {
                const errorEmbed = new Discord.MessageEmbed()
                  .setDescription('No se pudo quitar el rol. Asegúrate de que el bot y el usuario tengan los permisos adecuados.')
                  .setColor('#ff0000');
                message.channel.send(errorEmbed);
                console.error(error);
              });
          }
        } else {
          const incorrectUsageEmbed = new Discord.MessageEmbed()
            .setDescription('Uso incorrecto. Debes mencionar al usuario y al rol después de !quitarrol.')
            .setColor('#ff0000');
          message.channel.send(incorrectUsageEmbed);
        }
      } else {
        const incorrectUsageEmbed = new Discord.MessageEmbed()
          .Description('Uso incorrecto. Debes mencionar al usuario y el rol después de !quitarrol.')
          .setColor('#ff0000');
        message.channel.send(incorrectUsageEmbed);
      }
    } else {
      const noPermissionEmbed = new Discord.MessageEmbed()
        .setDescription('No tienes permisos para quitar roles.')
        .setColor('#ff0000');
      message.channel.send(noPermissionEmbed);
    }
  }
});

*/
// ...

client.on("message", async (message) => {
  if (message.content.startsWith("!desban")) {
    if (message.member.hasPermission("BAN_MEMBERS")) {
      const args = message.content.split(" ");
      if (args.length === 2) {
        const userID = args[1];

        const bannedUser = await client.users.fetch(userID);

        message.guild.members
          .unban(bannedUser)
          .then(() => {
            const unbanEmbed = new Discord.MessageEmbed()
              .setColor("#00ff00")
              .setTitle("Usuario Desbaneado")
              .addField("Usuario", `${bannedUser.tag} (${bannedUser.id})`)
              .addField("Desbaneado por", message.author.tag);

            const unbanLogChannel = message.guild.channels.cache.get(
              "1157890377227980881",
            );
            if (unbanLogChannel) {
              unbanLogChannel.send(unbanEmbed);
            }

            message.channel.send(`Usuario desbaneado: ${bannedUser.tag}`);
          })
          .catch((error) => {
            const errorEmbed = new Discord.MessageEmbed()
              .setDescription(
                "No se pudo desbanear al usuario. Asegúrate de que el bot y el usuario tengan los permisos adecuados.",
              )
              .setColor("#ff0000");
            message.channel.send(errorEmbed);
            console.error(error);
          });
      } else {
        const usageEmbed = new Discord.MessageEmbed()
          .setDescription(
            "Uso incorrecto. Debes proporcionar la ID del usuario después de !desbanear.",
          )
          .setColor("#ff0000");
        message.channel.send(usageEmbed);
      }
    } else {
      const noPermissionEmbed = new Discord.MessageEmbed()
        .setDescription("No tienes permisos para desbanear usuarios.")
        .setColor("#ff0000");
      message.channel.send(noPermissionEmbed);
    }
  }
});

client.on("message", (message) => {
  if (message.content.startsWith("!banear")) {
    if (message.member.hasPermission("BAN_MEMBERS")) {
      const args = message.content.split(" ");
      if (args.length < 2) {
        const usageEmbed = new Discord.MessageEmbed()
          .setDescription(
            "Uso incorrecto. Debes mencionar al usuario y proporcionar una razón después de !banear.",
          )
          .setColor("#ff0000");
        message.channel.send(usageEmbed);
        return;
      }

      const userID = args[1].replace(/<@!|>/g, ""); // Extrae la ID de usuario desde una mención
      const reason = args.slice(2).join(" ");

      const bannedUser = message.guild.members.cache.get(userID);

      if (bannedUser) {
        message.guild.members
          .ban(bannedUser, { reason: reason })
          .then(() => {
            const banEmbed = new Discord.MessageEmbed()
              .setColor("#ff0000")
              .setTitle("Usuario Baneado")
              .addField(
                "Usuario",
                `${bannedUser.user.tag} (${bannedUser.user.id})`,
              )
              .addField("Baneado por", message.author.tag)
              .addField("Razón", reason || "Sin razón especificada");

            const banLogChannel = message.guild.channels.cache.get(
              "1157890377227980881",
            );
            if (banLogChannel) {
              banLogChannel.send(banEmbed);
            }

            message.channel.send(`Usuario baneado: ${bannedUser.user.tag}`);
          })
          .catch((error) => {
            const errorEmbed = new Discord.MessageEmbed()
              .setDescription(
                "No se pudo banear al usuario. Asegúrate de que el bot y el usuario tengan los permisos adecuados.",
              )
              .setColor("#ff0000");
            message.channel.send(errorEmbed);
            console.error(error);
          });
      } else {
        const userNotFoundEmbed = new Discord.MessageEmbed()
          .setDescription(
            "No se pudo encontrar al usuario. Asegúrate de mencionar al usuario correctamente.",
          )
          .setColor("#ff0000");
        message.channel.send(userNotFoundEmbed);
      }
    } else {
      const noPermissionEmbed = new Discord.MessageEmbed()
        .setDescription("No tienes permisos para banear usuarios.")
        .setColor("#ff0000");
      message.channel.send(noPermissionEmbed);
    }
  }
});

client.on("message", async (message) => {
  if (message.content.startsWith("!desban")) {
    if (message.member.hasPermission("BAN_MEMBERS")) {
      const args = message.content.split(" ");
      if (args.length === 2) {
        const userID = args[1];

        const bannedUser = await client.users.fetch(userID);

        message.guild.members
          .unban(bannedUser)
          .then(() => {
            const unbanEmbed = new Discord.MessageEmbed()
              .setColor("#00ff00")
              .setTitle("Usuario Desbaneado")
              .addField("Usuario", `${bannedUser.tag} (${bannedUser.id})`)
              .addField("Desbaneado por", message.author.tag);

            const unbanLogChannel = message.guild.channels.cache.get(
              "1157890377227980881",
            );
            if (unbanLogChannel) {
              unbanLogChannel.send(unbanEmbed);
            }

            message.channel.send(`Usuario desbaneado: ${bannedUser.tag}`);
          })
          .catch((error) => {
            const errorEmbed = new Discord.MessageEmbed()
              .setDescription(
                "No se pudo desbanear al usuario. Asegúrate de que el bot y el usuario tengan los permisos adecuados.",
              )
              .setColor("#ff0000");
            message.channel.send(errorEmbed);
            console.error(error);
          });
      } else {
        const usageEmbed = new Discord.MessageEmbed()
          .setDescription(
            "Uso incorrecto. Debes proporcionar la ID del usuario después de !desbanear.",
          )
          .setColor("#ff0000");
        message.channel.send(usageEmbed);
      }
    } else {
      const noPermissionEmbed = new Discord.MessageEmbed()
        .setDescription("No tienes permisos para desbanear usuarios.")
        .setColor("#ff0000");
      message.channel.send(noPermissionEmbed);
    }
  }
});

client.on("message", (message) => {
  if (message.content.startsWith("!kick")) {
    if (message.member.hasPermission("KICK_MEMBERS")) {
      const args = message.content.split(" ");
      if (args.length === 2) {
        const userID = args[1].replace(/<@!|>/g, "");
        const member = message.guild.members.cache.get(userID);

        if (member) {
          member
            .kick()
            .then(() => {
              const kickEmbed = new Discord.MessageEmbed()
                .setColor("#ff0000")
                .setTitle("Usuario Expulsado")
                .addField("Usuario", `${member.user.tag} (${member.user.id})`)
                .addField("Expulsado por", message.author.tag);

              const kickLogChannel = message.guild.channels.cache.get(
                "1157890377227980881",
              );
              if (kickLogChannel) {
                kickLogChannel.send(kickEmbed);
              }

              message.channel.send(`Usuario expulsado: ${member.user.tag}`);
            })
            .catch((error) => {
              const errorEmbed = new Discord.MessageEmbed()
                .setDescription(
                  "No se pudo expulsar al usuario. Asegúrate de que el bot y el usuario tengan los permisos adecuados.",
                )
                .setColor("#ff0000");
              message.channel.send(errorEmbed);
              console.error(error);
            });
        } else {
          const notFoundEmbed = new Discord.MessageEmbed()
            .setDescription(
              "No se pudo encontrar al usuario. Asegúrate de mencionar al usuario correctamente.",
            )
            .setColor("#ff0000");
          message.channel.send(notFoundEmbed);
        }
      } else {
        const usageEmbed = new Discord.MessageEmbed()
          .setDescription(
            "Uso incorrecto. Debes mencionar al usuario después de !kick.",
          )
          .setColor("#ff0000");
        message.channel.send(usageEmbed);
      }
    } else {
      const noPermissionEmbed = new Discord.MessageEmbed()
        .setDescription("No tienes permisos para expulsar usuarios.")
        .setColor("#ff0000");
      message.channel.send(noPermissionEmbed);
    }
  }
});

client.on("message", (message) => {
  if (message.content.startsWith("!mute")) {
    if (message.member.hasPermission("MANAGE_ROLES")) {
      const args = message.content.split(" ");
      if (args.length === 2) {
        const userID = args[1].replace(/<@!|>/g, "");
        const member = message.guild.members.cache.get(userID);

        if (member) {
          const mutedRole = message.guild.roles.cache.find(
            (role) => role.name === "Muted",
          );

          if (mutedRole) {
            member.roles
              .add(mutedRole)
              .then(() => {
                const muteEmbed = new Discord.MessageEmbed()
                  .setColor("#3498db")
                  .setTitle("Usuario Mutado")
                  .addField(
                    "Usuario",
                    `${member.user.tag} (${member.user.id})`,
                  );

                message.channel.send(muteEmbed);
              })
              .catch((error) => {
                const errorEmbed = new Discord.MessageEmbed()
                  .setDescription(
                    "No se pudo mutear al usuario. Asegúrate de que el bot y el usuario tengan los permisos adecuados.",
                  )
                  .setColor("#ff0000");
                message.channel.send(errorEmbed);
                console.error(error);
              });
          } else {
            const roleNotFoundEmbed = new Discord.MessageEmbed()
              .setDescription(
                'No se encontró el rol "Muted". Asegúrate de que el rol exista en el servidor.',
              )
              .setColor("#ff0000");
            message.channel.send(roleNotFoundEmbed);
          }
        } else {
          const userNotFoundEmbed = new Discord.MessageEmbed()
            .setDescription(
              "No se pudo encontrar al usuario. Asegúrate de mencionar al usuario correctamente.",
            )
            .setColor("#ff0000");
          message.channel.send(userNotFoundEmbed);
        }
      } else {
        const usageEmbed = new Discord.MessageEmbed()
          .setDescription(
            "Uso incorrecto. Debes mencionar al usuario después de !mute.",
          )
          .setColor("#ff0000");
        message.channel.send(usageEmbed);
      }
    } else {
      const noPermissionEmbed = new Discord.MessageEmbed()
        .setDescription("No tienes permisos para mutear usuarios.")
        .setColor("#ff0000");
      message.channel.send(noPermissionEmbed);
    }
  }
});

client.on("message", (message) => {
  if (message.content.startsWith("!unmute")) {
    if (message.member.hasPermission("MANAGE_ROLES")) {
      const args = message.content.split(" ");
      if (args.length === 2) {
        const userID = args[1].replace(/<@!|>/g, "");
        const member = message.guild.members.cache.get(userID);

        if (member) {
          const mutedRole = message.guild.roles.cache.find(
            (role) => role.name === "Muted",
          );

          if (mutedRole) {
            member.roles
              .remove(mutedRole)
              .then(() => {
                const unmuteEmbed = new Discord.MessageEmbed()
                  .setColor("#3498db")
                  .setTitle("Usuario Desmuteado")
                  .addField(
                    "Usuario",
                    `${member.user.tag} (${member.user.id})`,
                  );

                message.channel.send(unmuteEmbed);
              })
              .catch((error) => {
                const errorEmbed = new Discord.MessageEmbed()
                  .setDescription(
                    "No se pudo desmutear al usuario. Asegúrate de que el bot y el usuario tengan los permisos adecuados.",
                  )
                  .setColor("#ff0000");
                message.channel.send(errorEmbed);
                console.error(error);
              });
          } else {
            const roleNotFoundEmbed = new Discord.MessageEmbed()
              .setDescription(
                'No se encontró el rol "Muted". Asegúrate de que el rol exista en el servidor.',
              )
              .setColor("#ff0000");
            message.channel.send(roleNotFoundEmbed);
          }
        } else {
          const userNotFoundEmbed = new Discord.MessageEmbed()
            .setDescription(
              "No se pudo encontrar al usuario. Asegúrate de mencionar al usuario correctamente.",
            )
            .setColor("#ff0000");
          message.channel.send(userNotFoundEmbed);
        }
      } else {
        const usageEmbed = new Discord.MessageEmbed()
          .setDescription(
            "Uso incorrecto. Debes mencionar al usuario después de !unmute.",
          )
          .setColor("#ff0000");
        message.channel.send(usageEmbed);
      }
    } else {
      const noPermissionEmbed = new Discord.MessageEmbed()
        .setDescription("No tienes permisos para desmutear usuarios.")
        .setColor("#ff0000");
      message.channel.send(noPermissionEmbed);
    }
  }
});

client.on("message", (message) => {
  if (message.content === "!comandos") {
    // Verifica si el autor del mensaje es un administrador
    const isAdmin = message.member.hasPermission("ADMINISTRATOR");

    // Comandos disponibles para todos
    const commonCommands = new MessageEmbed()
      .setColor("#3498db")
      .setTitle("Comandos Disponibles")
      .setDescription("Aquí tienes una lista de comandos disponibles:")
      .addField("!decir", "Para hacer que el bot hable un mensaje.")
      .addField("!register", "Para verificar usuarios.")
      .setTitle("Comandos de diversion")
      .addField("!dados", "Lanza un dado y prueba tu suerte.")
      .addField(
        "!suggest",
        "Envia una sugerencia a la administracion sobre el servidor.",
      )
      .addField("!abrazo", "Demuestra tu cariño a alguien.")
      .addField("!saludo", "Un saludo.....")
      .addField("!bola8", "Preguntale algo al bot.")
      .addField("!image", "El bot pone la imagen que pongas.");

    // Comandos adicionales para administradores
    const adminCommands = new MessageEmbed()
      .setColor("#3498db")
      .setTitle("Comandos Disponibles (Administradores)")
      .setDescription(
        "Aquí tienes una lista de comandos adicionales para administradores:",
      )
      .addField("!darrol", "Para otorgar un rol a un usuario específico.")
      .addField("!quitarrol", "Para quitar un rol a un usuario específico.")
      .addField("!mute", "Para mutear a un usuario.")
      .addField("!unmute", "Para desmutear a un usuario.")
      .addField("!banear", "Para banear a un usuario.")
      .addField("!desbanear", "Para desbanear a un usuario.")
      .addField("!kick", "Para expulsar a un usuario.")
      .addField("!dm", "Envía un mensaje a un usuario.")
      .addField(
        "!suggest",
        "Envia una sugerencia a la administracion sobre el servidor.",
      )
      .addField(
        "!aprovesuggest",
        "Acepta una sugerencia con la id de la misma.",
      )
      .setTitle("Comandos de usuarios")
      .addField("!decir", "Para hacer que el bot hable un mensaje.")
      .addField("!register", "Para verificar usuarios.")
      .addField("!dados", "Lanza un dado y prueba tu suerte.")
      .addField("!abrazo", "Demuestra tu cariño a alguien.")
      .addField("!saludo", "Un saludo.....")
      .addField(
        "!amor",
        "Calcula el porcentaje de amor entre un usuario y otro",
      )
      .addField("!bola8", "Preguntale algo al bot.")
      .addField("!image", "El bot pone la imagen que pongas.");

    // Envia los comandos apropiados al mismo canal donde se ejecutó el comando
    message.channel.send(isAdmin ? adminCommands : commonCommands).catch(() => {
      message.channel.send(
        "No puedo enviar mensajes al canal. Asegúrate de tener los permisos necesarios.",
      );
    });
  }
});

client.on("message", (message) => {
  if (message.content.startsWith("!bola8")) {
    const respuestas = [
      "Sí",
      "No",
      "Tal vez",
      "Definitivamente",
      "Mejor no te lo digo",
      "Pregunta de nuevo más tarde",
    ];
    const respuestaAleatoria =
      respuestas[Math.floor(Math.random() * respuestas.length)];
    const embed = new Discord.MessageEmbed()
      .setColor("#3498db")
      .setTitle("🎱 Respuesta del 8-Ball 🎱")
      .setDescription(`El 8-Ball dice: ${respuestaAleatoria}`);

    message.channel.send(embed);
  }
});
/*
client.on('message', async (message) => {
  if (message.content === '!saludo') {
    const saludoEmbed = new Discord.MessageEmbed()
      .setColor('#3498db')
      .setDescription(`¡Hola, ${message.author.username}!`)
      .setFooter('Saludo amigable');
    message.channel.send(saludoEmbed);
  }
});

client.on('message', async (message) => {
  if (message.content === '!dados') {
    const randomNumber = Math.floor(Math.random() * 6) + 1; // Tira un dado de 6 caras
    const dadosEmbed = new Discord.MessageEmbed()
      .setColor('#3498db')
      .setDescription(`Tiraste un dado y salió un ${randomNumber}`)
      .setFooter('Suerte en el juego');
    message.channel.send(dadosEmbed);
  }
});

client.on('message', async (message) => {
  if (message.content.startsWith('!abrazo')) {
    const targetUser = message.mentions.users.first();

    if (targetUser) {
      const abrazoEmbed = new Discord.MessageEmbed()
        .setColor('#3498db')
        .setDescription(`${message.author.username} te da un cálido abrazo, ${targetUser.username} ❤️`)
        .setFooter('Abrazo amigable');
      message.channel.send(abrazoEmbed);
    } else {
      const noMentionEmbed = new Discord.MessageEmbed()
        .setColor('#ff0000')
        .setDescription('¡Necesitas mencionar a alguien para darle un abrazo!')
        .setFooter('Error');
      message.channel.send(noMentionEmbed);
    }
  }
});

const { MessageEmbed } = require('discord.js');

client.on('message', async (message) => {
  if (message.content === '!snake') {
    // Configuración inicial del juego
    const gridSize = 5;
    const snake = [{ x: 2, y: 2 }]; // Cabeza de la serpiente
    const fruit = { x: 4, y: 4 }; // Fruta
    let score = 0;

    // Función para dibujar el tablero
    function drawBoard() {
      const board = [];
      for (let y = 0; y < gridSize; y++) {
        const row = [];
        for (let x = 0; x < gridSize; x++) {
          let cell = ':black_small_square:';
          if (x === fruit.x && y === fruit.y) {
            cell = ':green_apple:';
          } else if (snake.some(segment => segment.x === x && segment.y === y)) {
            cell = ':snake:';
          }
          row.push(cell);
        }
        board.push(row.join(''));
      }
      return board.join('\n');
    }

    const snakeEmbed = new MessageEmbed()
      .setColor('#3498db')
      .setTitle('Snake Game')
      .addField('Score', score)
      .setDescription(drawBoard())
      .setFooter('Reacciona con las flechas para mover la serpiente.');

    message.channel.send(snakeEmbed).then(async (msg) => {
      await msg.react('⬆️');
      await msg.react('⬇️');
      await msg.react('⬅️');
      await msg.react('➡️');

      const filter = (reaction, user) => user.id !== message.client.user.id;
      const collector = msg.createReactionCollector(filter, { time: 30000 }); // 30 segundos

      collector.on('collect', (reaction) => {
        // Aquí deberías implementar la lógica del juego, como mover la serpiente y detectar colisiones.
        // Puedes usar las reacciones para controlar la dirección de la serpiente.
        // Recuerda actualizar el tablero y el puntaje.
      });

      collector.on('end', (collected, reason) => {
        // Aquí puedes mostrar un mensaje de fin de juego o limpiar el tablero.
      });
    });
  }
});
*/
client.login(config.token || process.env.TOKEN);
