const SAMPQuery = require('samp-query');

// Crea una función para obtener el estado del servidor SA-MP
async function obtenerEstado() {
  const server = new SAMPQuery('192.99.20.120', 7777);

  try {
    const info = await server.retrieveBasicInfo();

    if (info) {
      return `Servidor SA-MP en 192.99.20.120:7777\nJugadores en línea: ${info.online}/${info.maxplayers}`;
    } else {
      return 'No se pudo obtener información del servidor.';
    }
  } catch (error) {
    return 'Error al obtener información del servidor: ' + error.message;
  }
}

module.exports = obtenerEstado;
