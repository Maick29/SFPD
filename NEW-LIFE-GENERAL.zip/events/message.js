/*
 * Copyright (c) 2020-2021, Bastian Leicht <mail@bastianleicht.de>
 *
 * PDX-License-Identifier: BSD-2-Clause
 */
const { prefix } = require('../config.json');
const Discord = require('discord.js'); // Agrega esta línea para importar discord.js


module.exports = (client, message) => {
  if (message.author.bot) return;

  // Si el mensaje es en un canal DM
  if (message.channel.type === 'dm') {
    const channelId = '1168760965953753128'; // ID del canal al que deseas enviar los mensajes DM
    const channel = client.channels.cache.get(channelId);

    // Comprueba si el canal existe antes de intentar enviar un mensaje
    if (channel) {
      const dmEmbed = new Discord.MessageEmbed()
        .setTitle('Mensaje DM')
        .setAuthor(message.author.username, message.author.displayAvatarURL())
        .setDescription(message.content); // Aquí se incluye el mensaje recibido

      channel.send(dmEmbed);
    }
  }



  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();

  const cmd = client.commands.get(command);
  if (!cmd) return;

  cmd.run(client, message, args, command);
};
